﻿"""Analysis adapters."""
