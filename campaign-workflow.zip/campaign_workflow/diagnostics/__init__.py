﻿"""Diagnostic adapters."""
